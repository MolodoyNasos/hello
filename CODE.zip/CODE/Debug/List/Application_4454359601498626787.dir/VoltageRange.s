///////////////////////////////////////////////////////////////////////////////
//
// IAR ANSI C/C++ Compiler V9.50.2.385/W64 for ARM        21/Apr/2026  14:38:46
// Copyright 1999-2024 IAR Systems AB.
//
//    Cpu mode     =  thumb
//    Endian       =  little
//    Source file  =
//        C:\Users\sadyk\OneDrive\Desktop\kurs\Application\VoltageRange.cpp
//    Command line =
//        -f
//        C:\Users\sadyk\OneDrive\Desktop\kurs\Debug\Obj\Application_4454359601498626787.dir\VoltageRange.o.rsp
//        (C:\Users\sadyk\OneDrive\Desktop\kurs\Application\VoltageRange.cpp
//        -lC
//        C:\Users\sadyk\OneDrive\Desktop\kurs\Debug\List\Application_4454359601498626787.dir
//        -lA
//        C:\Users\sadyk\OneDrive\Desktop\kurs\Debug\List\Application_4454359601498626787.dir
//        -o
//        C:\Users\sadyk\OneDrive\Desktop\kurs\Debug\Obj\Application_4454359601498626787.dir
//        --no_cse --no_unroll --no_inline --no_code_motion --no_tbaa
//        --no_clustering --no_scheduling --debug --endian=little
//        --cpu=Cortex-M4 -e --fpu=VFPv4_sp --dlib_config "C:\Program Files\IAR
//        Systems\Embedded Workbench 9.2\arm\inc\c\DLib_Config_Normal.h" -I
//        C:\Users\sadyk\OneDrive\Desktop\kurs\ -I
//        C:\Users\sadyk\OneDrive\Desktop\kurs\Application\ -I
//        C:\Users\sadyk\OneDrive\Desktop\kurs\Rtos\ -I
//        C:\Users\sadyk\OneDrive\Desktop\kurs\Rtos\FreeRtos\ -I
//        C:\Users\sadyk\OneDrive\Desktop\kurs\Rtos\FreeRtos\include\ -I
//        C:\Users\sadyk\OneDrive\Desktop\kurs\Rtos\FreeRtos\portable\ -I
//        C:\Users\sadyk\OneDrive\Desktop\kurs\Rtos\FreeRtos\portable\IAR\ARM_CM4F\
//        -I C:\Users\sadyk\OneDrive\Desktop\kurs\Rtos\wrapper\FreeRtos\ -I
//        C:\Users\sadyk\OneDrive\Desktop\kurs\Common\ -I
//        C:\Users\sadyk\OneDrive\Desktop\kurs\AHardware\ -I
//        C:\Users\sadyk\OneDrive\Desktop\kurs\AHardware\Registers\ -I
//        C:\Users\sadyk\OneDrive\Desktop\kurs\AHardware\Registers\CortexM4\FieldValues\
//        -I C:\Users\sadyk\OneDrive\Desktop\kurs\Rtos\wrapper\ -Ol --c++
//        --no_exceptions --no_rtti) --dependencies=n
//        C:\Users\sadyk\OneDrive\Desktop\kurs\Debug\Obj\Application_4454359601498626787.dir\VoltageRange.o.iar_deps
//    Locale       =  C
//    List file    =
//        C:\Users\sadyk\OneDrive\Desktop\kurs\Debug\List\Application_4454359601498626787.dir\VoltageRange.s
//
///////////////////////////////////////////////////////////////////////////////

        RTMODEL "__CPP_Exceptions", "Disabled"
        RTMODEL "__CPP_Language", "C++14"
        RTMODEL "__CPP_Library", "DLib"
        RTMODEL "__CPP_Runtime", "1"
        RTMODEL "__SystemLibrary", "DLib"
        RTMODEL "__dlib_file_descriptor", "0"
        RTMODEL "__dlib_full_locale_support", "0"
        RTMODEL "__dlib_version", "6"
        AAPCS BASE,INTERWORK,VFP
        PRESERVE8
        REQUIRE8

        #define SHT_PROGBITS 0x1

        PUBLIC _ZN22VoltageRangeCalculator11GetLedCountE12VoltageRange
        PUBLIC _ZN22VoltageRangeCalculator9CalculateEff
        
          CFI Names cfiNames0
          CFI StackFrame CFA R13 DATA
          CFI Resource R0:32, R1:32, R2:32, R3:32, R4:32, R5:32, R6:32, R7:32
          CFI Resource R8:32, R9:32, R10:32, R11:32, R12:32, R13:32, R14:32
          CFI Resource D0:64, D1:64, D2:64, D3:64, D4:64, D5:64, D6:64, D7:64
          CFI Resource D8:64, D9:64, D10:64, D11:64, D12:64, D13:64, D14:64
          CFI Resource D15:64
          CFI EndNames cfiNames0
        
          CFI Common cfiCommon0 Using cfiNames0
          CFI CodeAlign 2
          CFI DataAlign 4
          CFI ReturnAddress R14 CODE
          CFI CFA R13+0
          CFI R0 Undefined
          CFI R1 Undefined
          CFI R2 Undefined
          CFI R3 Undefined
          CFI R4 SameValue
          CFI R5 SameValue
          CFI R6 SameValue
          CFI R7 SameValue
          CFI R8 SameValue
          CFI R9 SameValue
          CFI R10 SameValue
          CFI R11 SameValue
          CFI R12 Undefined
          CFI R14 SameValue
          CFI D0 Undefined
          CFI D1 Undefined
          CFI D2 Undefined
          CFI D3 Undefined
          CFI D4 Undefined
          CFI D5 Undefined
          CFI D6 Undefined
          CFI D7 Undefined
          CFI D8 SameValue
          CFI D9 SameValue
          CFI D10 SameValue
          CFI D11 SameValue
          CFI D12 SameValue
          CFI D13 SameValue
          CFI D14 SameValue
          CFI D15 SameValue
          CFI EndCommon cfiCommon0
        
// C:\Users\sadyk\OneDrive\Desktop\kurs\Application\VoltageRange.cpp
//    1 #include "VoltageRange.hpp"
//    2 #include "Config.hpp"
//    3 

        SECTION `.text`:CODE:NOROOT(1)
          CFI Block cfiBlock0 Using cfiCommon0
          CFI Function _ZN22VoltageRangeCalculator9CalculateEff
          CFI NoCalls
        THUMB
//    4 VoltageRange VoltageRangeCalculator::Calculate(float voltage, float maxVoltage) {
//    5     float percentage = voltage / maxVoltage;
_ZN22VoltageRangeCalculator9CalculateEff:
        VDIV.F32 S0,S0,S1       
//    6     
//    7     if (percentage >= Config::LED_LEVEL_3) {
        VMOV.F32 S1,#0.75       
        VCMP.F32 S0,S1          
        FMSTAT                  
        BLT.N    ??Calculate_0  
//    8         return VoltageRange::LEVEL_3;
        MOVS     R0,#+3         
        B.N      ??Calculate_1  
//    9     } else if (percentage >= Config::LED_LEVEL_2) {
??Calculate_0:
        VMOV.F32 S1,#0.5        
        VCMP.F32 S0,S1          
        FMSTAT                  
        BLT.N    ??Calculate_2  
//   10         return VoltageRange::LEVEL_2;
        MOVS     R0,#+2         
        B.N      ??Calculate_1  
//   11     } else if (percentage >= Config::LED_LEVEL_1) {
??Calculate_2:
        VMOV.F32 S1,#0.25       
        VCMP.F32 S0,S1          
        FMSTAT                  
        BLT.N    ??Calculate_3  
//   12         return VoltageRange::LEVEL_1;
        MOVS     R0,#+1         
        B.N      ??Calculate_1  
//   13     } else {
//   14         return VoltageRange::LEVEL_0;
??Calculate_3:
        MOVS     R0,#+0         
??Calculate_1:
        BX       LR             
//   15     }
//   16 }
          CFI EndBlock cfiBlock0
//   17 

        SECTION `.text`:CODE:NOROOT(1)
          CFI Block cfiBlock1 Using cfiCommon0
          CFI Function _ZN22VoltageRangeCalculator11GetLedCountE12VoltageRange
          CFI NoCalls
        THUMB
//   18 uint8_t VoltageRangeCalculator::GetLedCount(VoltageRange range) {
//   19     switch (range) {
_ZN22VoltageRangeCalculator11GetLedCountE12VoltageRange:
        UXTB     R0,R0          
        CMP      R0,#+0         
        BEQ.N    ??GetLedCount_0
        CMP      R0,#+2         
        BEQ.N    ??GetLedCount_1
        BCC.N    ??GetLedCount_2
        CMP      R0,#+3         
        BNE.N    ??GetLedCount_3
//   20         case VoltageRange::LEVEL_3: return 4;
??GetLedCount_4:
        MOVS     R0,#+4         
        B.N      ??GetLedCount_5
//   21         case VoltageRange::LEVEL_2: return 3;
??GetLedCount_1:
        MOVS     R0,#+3         
        B.N      ??GetLedCount_5
//   22         case VoltageRange::LEVEL_1: return 2;
??GetLedCount_2:
        MOVS     R0,#+2         
        B.N      ??GetLedCount_5
//   23         case VoltageRange::LEVEL_0: return 1;
??GetLedCount_0:
        MOVS     R0,#+1         
        B.N      ??GetLedCount_5
//   24         default: return 0;
??GetLedCount_3:
        MOVS     R0,#+0         
??GetLedCount_5:
        BX       LR             
//   25     }
//   26 }
          CFI EndBlock cfiBlock1

        SECTION `.iar_vfe_header`:DATA:NOALLOC:NOROOT(2)
        SECTION_TYPE SHT_PROGBITS, 0
        DATA
        DC32 0

        END
// 
// 98 bytes in section .text
// 
// 98 bytes of CODE memory
//
//Errors: none
//Warnings: none
