#include "FreeRTOS.h"
#include "task.h"
#include "AHardware/I2C/I2C.h"
#include "AHardware/UART/USART.h"
#include "Application/Tasks/SensorTask.h"
#include "Application/Tasks/DisplayTask.h"
#include "Application/Tasks/LedTask.h"
#include "Application/Tasks/UartTask.h"
#include "rccregisters.hpp"

uint32_t SystemCoreClock = 16000000;

extern "C" void SVC_Handler(void) __attribute__((weak));
extern "C" void PendSV_Handler(void) __attribute__((weak));
extern "C" void SysTick_Handler(void) __attribute__((weak));

static void SystemClock_Config(void)
{
    RCC::CR::HSION::On::Set();
    while (RCC::CR::HSIRDY::Get() == 0) {}
    
    RCC::CFGR::HPRE::NoDiv::Set();
    RCC::CFGR::PPRE1::Div4::Set();
    
    RCC::CFGR::SW::Hsi::Set();
    while (RCC::CFGR::SWS::Get() != 0) {}
}

int main(void)
{
    SystemClock_Config();
    
    USART::Init(9600);
    USART::SendString("System start\r\n");
    
    I2C_Init();
    USART::SendString("I2C init done\r\n");
    
    SensorTask_Start();
    DisplayTask_Start();
    LedTask_Start();
    UartTask_Start();
    
    vTaskStartScheduler();
    
    while (1) {}
    
    return 0;
}