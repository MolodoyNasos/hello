/*******************************************************************************
* Filename  	: Rtos.hpp
*
* Details   	: Rtos class is used to create tasks, work with special Rtos
* functions and also it contains a special static method Run. In this method
* the pointer on Thread should be pass. This method is input point as
* the task of Rtos. In the body of the method, the method of concrete Thread
* will run.
*******************************************************************************/

#ifndef RTOS_HPP
#define RTOS_HPP

#include "thread.hpp"
#include "rtosdefs.hpp"
#include <cstddef>
#include "rtoswrapper.hpp"

namespace OsWrapper
{
  class Rtos
  {
  public:
    template<typename T>
    static void CreateThread(T& thread, const char *pName, ThreadPriority prior = ThreadPriority::normal)
    {
      RtosWrapper::wCreateThread<Rtos>(thread, pName, prior, thread.stackDepth, thread.stack);
    }

    static void Start()
    {
      RtosWrapper::wStart();
    }

    static void HandleSvcInterrupt()
    {
      RtosWrapper::wHandleSvcInterrupt();
    }

    static void HandleSysTickInterrupt()
    {
      RtosWrapper::wHandleSysTickInterrupt();
    }

    friend class RtosWrapper;

  private:
    static void Run(void *pContext)
    {
      static_cast<IThread*>(pContext)->Run();
    }
  };
}

#endif